"""Start the actual AstrBot core with extra local diagnostic sampling."""

import asyncio
import faulthandler
import json
import os
import signal
import sys
from pathlib import Path
from time import perf_counter

source = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(source))
os.chdir(source)

import runtime_bootstrap

runtime_bootstrap.initialize_runtime_bootstrap()

from astrbot.core import LogBroker, db_helper, logger, sp
from astrbot.core.core_lifecycle import AstrBotCoreLifecycle
from astrbot.core.star.star_handler import star_map
from astrbot.core.utils.event_loop_diagnostics import monitor_event_loop_lag

faulthandler.enable()
faulthandler.register(signal.SIGUSR1, all_threads=True)


async def main():
    """Run normal lifecycle, with plugins disabled through stored preferences."""
    await db_helper.initialize()
    await sp.initialize()
    disabled = [
        "astrbot.builtin_stars.astrbot.main",
        "astrbot.builtin_stars.builtin_commands.main",
    ]
    await sp.global_put("inactivated_plugins", disabled)
    core = AstrBotCoreLifecycle(LogBroker(), db_helper)
    await core.initialize()
    active = [item.name for item in star_map.values() if item.activated]
    logger.debug("REPRO plugin state: active=%s disabled=%s", active, disabled)
    assert not active, active
    assert not list((Path(os.environ["ASTRBOT_ROOT"]) / "data" / "plugins").glob("*/main.py"))

    async def sample_lag():
        loop = asyncio.get_running_loop()
        expected = loop.time() + 0.01
        path = Path(os.environ["ASTRBOT_ROOT"]) / "loop-lag.jsonl"
        with path.open("w", buffering=1) as handle:
            while True:
                await asyncio.sleep(0.01)
                now = loop.time()
                lag = max(0.0, now - expected)
                if lag > 0.02:
                    handle.write(json.dumps({"monotonic": perf_counter(), "lag_ms": lag * 1000}) + "\n")
                expected = now + 0.01

    diagnostics = [
        asyncio.create_task(monitor_event_loop_lag(interval=0.01, warn_after=0.1)),
        asyncio.create_task(sample_lag()),
    ]
    logger.info("REPRO extra upstream lag monitor: interval=0.010s warn_after=0.100s; core methods unmodified")
    try:
        await core.start()
    except asyncio.CancelledError:
        pass
    finally:
        for task in diagnostics:
            task.cancel()
        await asyncio.gather(*diagnostics, return_exceptions=True)
        await core.stop()


asyncio.run(main(), debug=True)
