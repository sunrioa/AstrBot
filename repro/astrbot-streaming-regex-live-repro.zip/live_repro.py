"""Exercise an actual AstrBot instance through local LLM and OneBot protocols."""

import argparse
import asyncio
import hashlib
import json
import os
import platform
import re
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import aiohttp
from aiohttp import web

ORIGINAL = 're.compile(r"[^。？！~…]+[。？！~…]+")'
ANCHORED = 're.compile(r"(?:^|(?<=[。？！~…]))[^。？！~…]+[。？！~…]+")'
HERE = Path(__file__).resolve().parent


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def timestamp():
    return datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="milliseconds")


async def run_variant(source, out, variant, repeats):
    """Boot one fresh instance and feed protocol-level test messages."""
    root = out / variant
    (root / "data").mkdir(parents=True, exist_ok=True)
    ws_port, llm_port = free_port(), free_port()
    config = {
        "config_version": 5,
        "dashboard": {"enable": False, "host": "127.0.0.1", "password": hashlib.md5(b"local-repro-only").hexdigest()},
        "log_level": "DEBUG", "log_file_enable": True,
        "log_file_path": "logs/astrbot.log", "disable_metrics": True,
        "t2i": False, "t2i_endpoint": f"http://127.0.0.1:{llm_port}/unused",
        "platform_settings": {"enable_id_white_list": False, "reply_with_mention": False, "reply_with_quote": False, "segmented_reply": {"enable": False}},
        "platform": [{"id": "local-onebot", "type": "aiocqhttp", "enable": True, "ws_reverse_host": "127.0.0.1", "ws_reverse_port": ws_port, "ws_reverse_token": ""}],
        "provider_sources": [{"id": "local-source", "type": "openai_chat_completion", "provider": "openai", "provider_type": "chat_completion", "enable": True, "key": ["local-repro-placeholder"], "api_base": f"http://127.0.0.1:{llm_port}/v1", "timeout": 120}],
        "provider": [{"id": "local-model", "provider_source_id": "local-source", "type": "openai_chat_completion", "provider_type": "chat_completion", "enable": True, "model": "local-repro-model"}],
        "provider_settings": {"enable": True, "streaming_response": True, "unsupported_streaming_strategy": "realtime_segmenting", "identifier": False, "proactive_capability": {"add_cron_tools": False}},
        "agent_runner": {"runner_type": "local", "config": {"model": {"provider_id": "local-model", "fallback_provider_ids": [], "request_max_retries": 1}}},
    }
    (root / "data" / "cmd_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2))
    wire = (root / "protocol.jsonl").open("w", buffering=1)
    pending = {}
    child = None
    ws = None
    counter = 0

    def log(event, **details):
        entry = {"time": timestamp(), "monotonic": time.perf_counter(), "event": event, **details}
        wire.write(json.dumps(entry, ensure_ascii=False) + "\n")

    async def llm(request):
        payload = await request.json()
        users = [m.get("content", "") for m in payload.get("messages", []) if m.get("role") == "user"]
        last = users[-1] if users else ""
        if isinstance(last, list):
            last = "".join(part.get("text", "") for part in last if isinstance(part, dict))
        kind = "probe" if "PROBE" in str(last) else "main"
        case_match = re.search(r"(?:REPRO|PROBE):(case\d+)", str(last))
        case_id = case_match.group(1) if case_match else "unknown"
        if kind == "main":
            try:
                case = pending[case_id]
            except (KeyError, IndexError):
                log("unexpected_llm_request", last=str(last)[:500])
                return web.json_response({"error": {"message": "Unknown local case", "type": "invalid_request_error"}}, status=400)
            case["provider_received"] = time.perf_counter()
        else:
            case = pending[case_id]
            case["probe_provider_received"] = time.perf_counter()
        log("llm_request", case=case_id, kind=kind, stream=payload.get("stream"), model=payload.get("model"))
        assert payload.get("stream") is True
        response = web.StreamResponse(headers={"Content-Type": "text/event-stream", "Cache-Control": "no-cache"})
        await response.prepare(request)

        async def emit(content=None, finish=None):
            chunk = {"id": "chatcmpl-local-repro", "object": "chat.completion.chunk", "created": int(time.time()), "model": "local-repro-model", "choices": [{"index": 0, "delta": ({"role": "assistant", "content": content} if content is not None else {}), "finish_reason": finish}]}
            await response.write(("data: " + json.dumps(chunk, ensure_ascii=False) + "\n\n").encode())

        if kind == "probe":
            await emit("probe-ok。")
        else:
            await emit("。")
            await asyncio.sleep(0.15)
            for index, count in enumerate(case["chunks"]):
                if index == 0:
                    case["first_tail_sent"] = time.perf_counter()
                log("llm_tail_chunk", case=case_id, index=index, chars=count)
                await emit("a" * count)
                if case.get("with_probe") and index == 0:
                    await asyncio.sleep(0.10)
                    case["probe_sent"] = time.perf_counter()
                    await ws.send_json(message(99001, "PROBE:" + case_id))
                    log("probe_sent", case=case_id)
                    os.kill(child.pid, signal.SIGUSR1)
                await asyncio.sleep(0.15)
        await emit(finish="stop")
        await response.write(b"data: [DONE]\n\n")
        await response.write_eof()
        return response

    def message(user_id, text):
        nonlocal counter
        counter += 1
        return {"time": int(time.time()), "self_id": 90001, "post_type": "message", "message_type": "private", "sub_type": "friend", "message_id": counter, "user_id": user_id, "message": [{"type": "text", "data": {"text": text}}], "raw_message": text, "font": 0, "sender": {"user_id": user_id, "nickname": f"LocalUser{user_id}", "sex": "unknown", "age": 0}}

    async def receive():
        async for packet in ws:
            if packet.type != aiohttp.WSMsgType.TEXT:
                continue
            payload = packet.json()
            action, params = payload.get("action"), payload.get("params", {})
            data = {}
            if action == "get_login_info":
                data = {"user_id": 90001, "nickname": "LocalReproBot"}
            elif action == "get_status":
                data = {"online": True, "good": True}
            elif action == "get_version_info":
                data = {"app_name": "local-onebot-fixture", "app_version": "1", "protocol_version": "v11"}
            elif action in ("get_group_list", "get_friend_list"):
                data = []
            elif action == "get_stranger_info":
                data = {"user_id": params.get("user_id"), "nickname": "LocalUser"}
            elif action in ("send_private_msg", "send_group_msg", "send_msg"):
                components = params.get("message", [])
                text_value = components if isinstance(components, str) else "".join(c.get("data", {}).get("text", "") for c in components if c.get("type") == "text")
                user_id = int(params.get("user_id", 0))
                digest = hashlib.sha256(text_value.encode()).hexdigest()
                log("onebot_send", action=action, user_id=user_id, chars=len(text_value), sha256=digest, preview=text_value[:70])
                for case in pending.values():
                    if case["user_id"] == user_id and not case["done"].done():
                        case["reply_received"] = time.perf_counter()
                        case["reply_chars"] = len(text_value)
                        case["reply_sha256"] = digest
                        case["reply_text_ok"] = text_value == "。" + "a" * sum(case["chunks"])
                        case["done"].set_result(None)
                if user_id == 99001:
                    for case in pending.values():
                        if case.get("with_probe") and not case["probe_done"].done():
                            case["probe_reply_received"] = time.perf_counter()
                            case["probe_done"].set_result(None)
                data = {"message_id": counter + 100000}
            log("onebot_action", action=action)
            await ws.send_json({"status": "ok", "retcode": 0, "data": data, "echo": payload.get("echo")})

    app = web.Application()
    app.router.add_post("/v1/chat/completions", llm)
    app.router.add_get("/v1/models", lambda _: web.json_response({"object": "list", "data": [{"id": "local-repro-model", "object": "model"}]}))
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    await web.TCPSite(runner, "127.0.0.1", llm_port).start()
    log("variant_start", variant=variant, python=sys.version, platform=platform.platform())
    env = dict(os.environ, ASTRBOT_ROOT=str(root), ASTRBOT_DISABLE_METRICS="1", PYTHONUNBUFFERED="1", PYTHONASYNCIODEBUG="1", TZ="Asia/Shanghai")
    results = []
    try:
        with (root / "astrbot-console.log").open("w") as console:
            child = await asyncio.create_subprocess_exec(sys.executable, str(HERE / "headless.py"), str(source), env=env, stdout=console, stderr=asyncio.subprocess.STDOUT)
            async with aiohttp.ClientSession() as session:
                for _ in range(180):
                    if child.returncode is not None:
                        raise RuntimeError(f"AstrBot exited: {child.returncode}; see {root / 'astrbot-console.log'}")
                    try:
                        ws = await session.ws_connect(f"http://127.0.0.1:{ws_port}/ws", headers={"X-Self-ID": "90001", "X-Client-Role": "Universal"})
                        break
                    except (aiohttp.ClientError, OSError):
                        await asyncio.sleep(0.5)
                else:
                    raise TimeoutError("OneBot reverse WebSocket did not start")
                receiver = asyncio.create_task(receive())
                await ws.send_json({"time": int(time.time()), "self_id": 90001, "post_type": "meta_event", "meta_event_type": "lifecycle", "sub_type": "connect"})
                await asyncio.sleep(1)
                cases = [(n, [n], rep) for n in (5000, 10000, 20000) for rep in range(repeats)] + [(20000, [5000] * 4, 0)]
                for index, (n, chunks, rep) in enumerate(cases):
                    case_id = f"case{index}"
                    case = {"user_id": 10001 + index, "tail_chars": n, "chunks": chunks, "repeat": rep, "with_probe": n == 20000 and len(chunks) == 1 and rep == 0, "done": asyncio.get_running_loop().create_future(), "probe_done": asyncio.get_running_loop().create_future()}
                    pending[case_id] = case
                    start = time.perf_counter()
                    case["started"] = start
                    log("case_start", case=case_id, n=n, chunks=chunks)
                    await ws.send_json(message(case["user_id"], "REPRO:" + case_id))
                    await asyncio.wait_for(asyncio.shield(case["done"]), timeout=90)
                    if case["with_probe"]:
                        await asyncio.wait_for(asyncio.shield(case["probe_done"]), timeout=30)
                    await asyncio.sleep(0.5)
                    finish = time.perf_counter()
                    lags = [json.loads(line) for line in (root / "loop-lag.jsonl").read_text().splitlines()]
                    row = {"variant": variant, "case": case_id, "tail_chars": n, "chunks": chunks, "repeat": rep, "reply_latency_ms": (case["reply_received"] - start) * 1000, "first_tail_to_reply_ms": (case["reply_received"] - case["first_tail_sent"]) * 1000, "max_loop_lag_ms": max((item["lag_ms"] for item in lags if start <= item["monotonic"] <= finish), default=0), "reply_chars": case["reply_chars"], "reply_sha256": case["reply_sha256"], "reply_text_ok": case["reply_text_ok"]}
                    if case["with_probe"]:
                        row["probe_to_provider_ms"] = (case["probe_provider_received"] - case["probe_sent"]) * 1000
                        row["probe_reply_latency_ms"] = (case["probe_reply_received"] - case["probe_sent"]) * 1000
                    assert row["reply_text_ok"], row
                    results.append(row)
                    log("case_result", **row)
                    print(json.dumps(row), flush=True)
                    (root / "results.json").write_text(json.dumps(results, indent=2) + "\n")
                await ws.close()
                await receiver
    finally:
        if child is not None and child.returncode is None:
            child.send_signal(signal.SIGINT)
            try:
                await asyncio.wait_for(child.wait(), 15)
            except asyncio.TimeoutError:
                child.kill()
                await child.wait()
        await runner.cleanup()
        wire.close()
    return results


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=HERE / "runs")
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    target = args.source / "astrbot/core/platform/sources/aiocqhttp/aiocqhttp_message_event.py"
    baseline = target.read_text()
    assert baseline.count(ORIGINAL) == 1
    all_results = []
    try:
        for variant in ("original", "anchored"):
            target.write_text(baseline if variant == "original" else baseline.replace(ORIGINAL, ANCHORED))
            (args.out / f"{variant}.diff").write_text(subprocess.check_output(["git", "diff", "--", str(target)], cwd=args.source, text=True))
            all_results.extend(await run_variant(args.source, args.out, variant, args.repeats))
    finally:
        target.write_text(baseline)
    (args.out / "results.json").write_text(json.dumps(all_results, indent=2) + "\n")
    print("Completed both variants; original source restored.", flush=True)


asyncio.run(main())
