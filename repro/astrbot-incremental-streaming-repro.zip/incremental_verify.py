"""Compare actual incremental delivery with pinned legacy implementations."""

import ast
import asyncio
import itertools
import json
import random
import re
import subprocess
import sys
from collections.abc import AsyncGenerator
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace
from unittest.mock import patch

SOURCE = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(SOURCE))

from astrbot.core.message.components import Image, Plain
from astrbot.core.message.message_event_result import MessageChain
from astrbot.core.platform.astr_message_event import AstrMessageEvent
from astrbot.core.platform.sources.aiocqhttp import aiocqhttp_message_event as current

OUT = Path(__file__).resolve().parent / "incremental-verification.json"
ORIGINAL = r"[^。？！~…]+[。？！~…]+"
ANCHORED = r"(?:^|(?<=[。？！~…]))[^。？！~…]+[。？！~…]+"
stats = {"calls": 0, "chars": 0}


class CountedPattern:
    def __init__(self, pattern):
        self.inner = re.compile(pattern)

    def finditer(self, value):
        stats["calls"] += 1
        stats["chars"] += len(value)
        return self.inner.finditer(value)


def counted_search(pattern, value):
    stats["calls"] += 1
    stats["chars"] += len(value)
    return pattern.inner.search(value)


counted_re = SimpleNamespace(compile=CountedPattern, search=counted_search, Pattern=re.Pattern)


async def no_delay(*args, **kwargs):
    pass


def legacy(fixed):
    namespace = {"AstrMessageEvent": AstrMessageEvent, "asyncio": asyncio,
                 "re": counted_re, "MessageChain": MessageChain,
                 "Plain": Plain, "AsyncGenerator": AsyncGenerator}
    nodes = []
    for filename, class_name, method in (
        ("astrbot/core/platform/astr_message_event.py", "AstrMessageEvent", "process_buffer"),
        ("astrbot/core/platform/sources/aiocqhttp/aiocqhttp_message_event.py", "AiocqhttpMessageEvent", "send_streaming"),
    ):
        content = subprocess.check_output(["git", "show", "f926af9:" + filename], cwd=SOURCE, text=True)
        tree = ast.parse(content)
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name)
        node = next(node for node in cls.body if isinstance(node, ast.AsyncFunctionDef) and node.name == method)
        if fixed:
            for child in ast.walk(node):
                if isinstance(child, ast.Constant) and child.value == ORIGINAL:
                    child.value = ANCHORED
        nodes.append(node)
    cls = ast.ClassDef(name="Legacy", bases=[ast.Name(id="AstrMessageEvent", ctx=ast.Load())],
                       keywords=[], body=nodes, decorator_list=[], type_params=[])
    module = ast.fix_missing_locations(ast.Module(body=[cls], type_ignores=[]))
    exec(compile(module, "pinned-upstream.py", "exec"), namespace)
    return namespace["Legacy"]


async def deliver(Event, chains, fallback=True):
    event = Event.__new__(Event)
    sent = []

    async def send(chain):
        sent.append([(type(comp).__name__, comp.text if isinstance(comp, Plain) else comp.file)
                     for comp in chain.chain])

    event.send = send

    async def stream():
        for chain in chains:
            yield MessageChain([Plain(item) if isinstance(item, str) else Image.fromURL("https://example.com/image.png") for item in chain])

    await event.send_streaming(stream(), fallback)
    return sent


async def main():
    original, anchored = legacy(False), legacy(True)
    report = {"source_base": "f926af99ec5f8bd85b64413f8bfad55da76ef73b"}
    count = 0
    with patch.object(AstrMessageEvent, "send_streaming", no_delay), patch.object(asyncio, "sleep", no_delay), patch.object(current, "re", counted_re):
        for length in range(7):
            for chars in itertools.product("a。… ", repeat=length):
                chains = [["".join(chars)]]
                assert await deliver(original, chains) == await deliver(current.AiocqhttpMessageEvent, chains), chains
                count += 1
        report["exhaustive_single_component"] = count
        count = 0
        for length in range(6):
            for chars in itertools.product("a。…", repeat=length):
                text = "".join(chars)
                for mask in range(1 << max(0, length - 1)):
                    chunks, start = [], 0
                    for index in range(1, length):
                        if mask & (1 << (index - 1)):
                            chunks.append([text[start:index]])
                            start = index
                    chunks.append([text[start:]])
                    assert await deliver(original, chunks) == await deliver(current.AiocqhttpMessageEvent, chunks), chunks
                    count += 1
        report["exhaustive_chunk_partitions"] = count
        rng = random.Random(20261104)
        for index in range(5000):
            chains = []
            for _ in range(rng.randrange(12)):
                chain = []
                for _ in range(rng.randrange(5)):
                    chain.append(None if rng.random() < 0.1 else "".join(rng.choices("a文😀。？！~…\n\t .!?,、`/:019", k=rng.randrange(25))))
                chains.append(chain)
            for fallback in (True, False) if index < 200 else (True,):
                assert await deliver(original, chains, fallback) == await deliver(current.AiocqhttpMessageEvent, chains, fallback), (fallback, chains)
        report["random_mixed_component_streams"] = 5000
        report["nonfallback_streams"] = 200
        for chains in ([["。"]] * 1000, [["a。" * 200 + "tail"]], [["。"], ["a"]] * 500):
            assert await deliver(original, chains) == await deliver(current.AiocqhttpMessageEvent, chains)
        report["long_boundary_streams"] = 3
        print(json.dumps({"equivalence": report}), flush=True)
        report["one_character_chunk_cost"] = []
        for n in (5000, 10000, 20000):
            chains = [["。"]] + [["a"]] * n
            row = {"tail_chars": n}
            for name, Event in (("anchored", anchored), ("incremental", current.AiocqhttpMessageEvent)):
                stats.update(calls=0, chars=0)
                started = perf_counter()
                sent = await deliver(Event, chains)
                row[name] = {"ms": (perf_counter() - started) * 1000, **stats}
                assert sent == [[("Plain", "。" + "a" * n)]]
                assert stats["chars"] == ((n + 1) * (n + 2) // 2 if name == "anchored" else n + 1)
            report["one_character_chunk_cost"].append(row)
            print(json.dumps(row), flush=True)
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")


asyncio.run(main())
