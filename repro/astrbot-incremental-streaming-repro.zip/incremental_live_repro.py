"""Compare the previous anchored PR with incremental delivery in full instances."""

import asyncio
import json
import subprocess
import sys
from pathlib import Path

from live_repro import run_variant

SOURCE = Path(sys.argv[1]).resolve()
OUT = Path(__file__).resolve().parent / "runs-incremental"


async def main():
    target = SOURCE / "astrbot/core/platform/sources/aiocqhttp/aiocqhttp_message_event.py"
    incremental = target.read_text()
    anchored = subprocess.check_output(
        ["git", "show", "dd224a7:astrbot/core/platform/sources/aiocqhttp/aiocqhttp_message_event.py"],
        cwd=SOURCE, text=True,
    )
    results = []
    try:
        for variant, content in (("anchored", anchored), ("incremental", incremental)):
            target.write_text(content)
            results.extend(await run_variant(SOURCE, OUT, variant, repeats=1, tiny_chunks=True))
    finally:
        target.write_text(incremental)
    for case in {row["case"] for row in results}:
        original, fixed = [row for row in results if row["case"] == case]
        assert original["reply_sha256"] == fixed["reply_sha256"], case
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print("All 14 primary replies and 7 paired checksums verified; incremental source restored.", flush=True)


asyncio.run(main())
